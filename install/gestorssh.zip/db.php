<?php
$Usuario = "root";
$Senha = "2585";
$Host = "localhost";
$Database = "db";

if (mysql_connect($Host, $Usuario, $Senha)){
    mysql_select_db($Database);
    }
?>